
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../models/test_result_model.dart';
import '../../../services/gemini_service.dart';
import '../../../theme/app_theme.dart';

class RecommendationsTabWidget extends StatefulWidget {
  final TestResultModel testResult;

  const RecommendationsTabWidget({
    super.key,
    required this.testResult,
  });

  @override
  State<RecommendationsTabWidget> createState() => _RecommendationsTabWidgetState();
}

class _RecommendationsTabWidgetState extends State<RecommendationsTabWidget> {
  String? aiRecommendations;
  String? performanceInsights;
  bool isLoadingRecommendations = false;
  bool isLoadingInsights = false;

  @override
  void initState() {
    super.initState();
    _loadRecommendations();
  }

  Future<void> _loadRecommendations() async {
    setState(() {
      isLoadingRecommendations = true;
      isLoadingInsights = true;
    });

    try {
      // Build subjectScores map from model
      final Map<String, double> subjectScores = widget.testResult.subjectResults.map(
        (k, v) => MapEntry(k, v.scorePercent),
      );
      // Call top-level service function (provide your real API key here)
      final recs = await generateStudyRecommendations(
        overallScore: widget.testResult.overallScore,
        subjectScores: subjectScores,
        weakTopics: widget.testResult.weakTopics,
        timeSpent: widget.testResult.timeSpent,
        accuracyRate: widget.testResult.accuracyRate,
        apiKey: 'mock_key',
      );

      // Simple local performance insight text
      final current = widget.testResult.overallScore.toStringAsFixed(1);
      final previous = widget.testResult.previousAttempt?.score.toStringAsFixed(1) ?? '—';
      final delta = widget.testResult.previousAttempt == null
          ? ''
          : ' (Δ ${(widget.testResult.overallScore - widget.testResult.previousAttempt!.score).toStringAsFixed(1)})';

      setState(() {
        aiRecommendations = recs;
        performanceInsights = 'Current: $current% • Previous: $previous%$delta';
        isLoadingRecommendations = false;
        isLoadingInsights = false;
      });
    } catch (e) {
      setState(() {
        aiRecommendations = _generateFallbackRecommendations();
        performanceInsights = _generateFallbackInsights();
        isLoadingRecommendations = false;
        isLoadingInsights = false;
      });
    }
  }

  String _generateFallbackRecommendations() {
    final weakTopics = widget.testResult.weakTopics;
    final strongTopics = widget.testResult.strongTopics;
    return [
      if (weakTopics.isNotEmpty) '• In topics: ${weakTopics.join(', ')}  —  25 min spaced practice daily',
      if (strongTopics.isNotEmpty) '• Strong areas: ${strongTopics.join(', ')}  —  2–3 weekly mixed tests to retain',
      '• Revise mistakes from last attempt first, then do topic-wise quizzes',
    ].join('\n');
  }

  String _generateFallbackInsights() {
    final tr = widget.testResult;
    final attempted = tr.correctAnswers + tr.incorrectAnswers;
    final speed = attempted == 0 ? 0 : tr.timeSpent / attempted;
    return 'Accuracy ${tr.accuracyRate.toStringAsFixed(1)}% • Avg time/question ${speed.toStringAsFixed(1)}s';
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildCard(
            title: 'AI Study Plan',
            loading: isLoadingRecommendations,
            content: aiRecommendations,
          ),
          SizedBox(height: 2.h),
          _buildCard(
            title: 'Performance Insights',
            loading: isLoadingInsights,
            content: performanceInsights,
          ),
          SizedBox(height: 3.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildAction('Retake Test', Icons.replay, _onRetakeTest),
              _buildAction('Practice Weak', Icons.fitness_center, _onPracticeWeakTopics),
              _buildAction('Create Schedule', Icons.calendar_today, _onCreateSchedule),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCard({required String title, required bool loading, required String? content}) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.inter(
              fontSize: 14.sp,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimaryLight,
            ),
          ),
          SizedBox(height: 1.h),
          if (loading)
            Row(
              children: [
                const CircularProgressIndicator(strokeWidth: 2),
                SizedBox(width: 3.w),
                Text('Loading...', style: GoogleFonts.inter(fontSize: 12.sp)),
              ],
            )
          else
            Text(
              (content == null || content.trim().isEmpty) ? '—' : content,
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                color: AppTheme.textSecondaryLight,
                height: 1.4,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAction(String title, IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.2.h),
        decoration: BoxDecoration(
          color: AppTheme.accentLight.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppTheme.accentLight, size: 6.w),
            SizedBox(width: 2.w),
            Text(
              title,
              style: GoogleFonts.inter(
                fontSize: 11.sp,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimaryLight,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _onRetakeTest() {}
  void _onPracticeWeakTopics() {}
  void _onCreateSchedule() {}
}
